# 商业与财务学习中心 | MEE

一个专注于商业、财务和经济学习的现代化Web应用，为用户提供丰富的学习资源、实用工具和最新财经资讯。

## 项目特性

- 📊 **财务计算器**：包含投资回报率、毛利率、现金流等多种实用计算器
- 📚 **学习路径**：精心设计的商业、金融、经济学习路径
- 🎓 **Excel教程**：专业的财务Excel技能提升视频教程
- 📰 **财经时讯**：每日更新的全球财经新闻与市场分析
- 💼 **商业角色指南**：深入解析CEO、CFO、CTO、CMO等关键商业角色

## 技术栈

- **前端框架**：React 18+
- **语言**：TypeScript
- **构建工具**：Vite
- **样式方案**：Tailwind CSS
- **动画效果**：Framer Motion
- **图表库**：Recharts
- **路由管理**：React Router
- **图标库**：Font Awesome

## 快速开始

### 前提条件

确保您的环境中已安装以下工具：
- Node.js (v16+)
- npm/yarn/pnpm

### 安装依赖

```bash
npm install
# 或
yarn install
# 或
pnpm install
```

### 开发模式

```bash
npm run dev
# 或
yarn dev
# 或
pnpm dev
```

应用将运行在 http://localhost:3000

### 构建生产版本

要生成可部署的dist文件，请运行：

```bash
npm run build
# 或
yarn build
# 或
pnpm build
```

这将在项目根目录下生成一个`dist`文件夹，包含所有优化后的静态资源文件。

### 部署到GitHub Pages

如果您想直接部署到GitHub Pages，可以使用以下命令：

```bash
npm run deploy
# 或
yarn deploy
# 或
pnpm deploy
```

## 项目结构

```
src/
├── components/        # 可复用组件
├── contexts/          # React上下文
├── hooks/             # 自定义Hooks
├── lib/               # 工具函数
├── pages/             # 页面组件
├── App.tsx            # 应用主组件
├── index.css          # 全局样式
└── main.tsx           # 应用入口
```

## 部署指南

### 部署到GitHub Pages

1. 确保您已经将项目推送到GitHub仓库（仓库名为`mee`）
2. 运行`npm run deploy`命令，该命令会自动构建项目并部署到GitHub Pages
3. 部署完成后，您的网站将可通过`https://[your-username].github.io/mee/`访问

### 部署到其他平台

项目生成的`dist`文件夹包含了所有必要的静态文件，您可以将其部署到任何支持静态网站托管的平台，如：
- Vercel
- Netlify
- AWS S3
- 阿里云OSS等

## 自定义配置

如需修改项目配置，可以编辑以下文件：
- `vite.config.ts`：Vite配置
- `tailwind.config.js`：Tailwind CSS配置
- `postcss.config.js`：PostCSS配置

## 注意事项

- 项目使用了响应式设计，支持桌面和移动设备
- 所有图片通过`space.coze.cn` API生成，请确保网络连接正常
- 本地开发时，如有任何问题，请尝试删除`node_modules`并重新安装依赖

## License

MIT